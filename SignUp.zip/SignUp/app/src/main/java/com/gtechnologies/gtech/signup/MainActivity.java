package com.gtechnologies.gtech.signup;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final String registerrequesturl="http://sd.smrobi.com/api/OwnerRegApi.php";

  public   Button btn_sign_up;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_sign_up=findViewById(R.id.sign_up);
        btn_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Intent intent=new Intent(MainActivity.this,Main2Activity.class);
                //startActivity(intent);
               registerProcess();


            }
        });
    }
    private void registerProcess() {
        StringRequest stringRequest=new StringRequest(Request.Method.POST, registerrequesturl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            String result=jsonObject.getString("result");
                            if(result.equals("Success")){

                                Toast.makeText(MainActivity.this,"You registered"+result,Toast.LENGTH_LONG).show();
                            }
                            else{


                                Toast.makeText(MainActivity.this,"Error Occured"+result,Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(MainActivity.this,"Error Occured"+error.toString(),Toast.LENGTH_LONG).show();

            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>  params=new HashMap<>();
                params.put("id",2+"");
                params.put("ownerName","alu");
                params.put("presentAddress","dhaka");
                params.put("ownerMobile",123+"");
                params.put("ownerEmail","@gmail");
                params.put("religion","islam");
                params.put("professsion","eng");
                params.put("professsionDetails","ghj");
                params.put("professsionAddress","ku");
                params.put("jobPreference","wed");
                params.put("jobLocation","kh");
                params.put("carName","bw");
                params.put("startDate","5/5/7");
                params.put("offerSalary",233+"");
                params.put("education","ssc");
                params.put("expYear","3yr");
                params.put("accomodation","vitaa");
                params.put("workingHours",34+"");
                params.put("lunch","money");
                params.put("status","good");
                params.put("remarks","goood");
                params.put("userName","alamin");
                return params;
            }
        };

         RequestQueue requestQueue=Volley.newRequestQueue(MainActivity.this);
         requestQueue.add(stringRequest);
        }



    }

