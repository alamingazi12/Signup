package com.gtechnologies.gtech.signup;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.icu.util.Calendar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

public class Main2Activity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, DatePickerDialog.OnDateSetListener {
    String[] religion={"Select here","islam","hindu","Others"};
    String[] education1={"Select here","Class Eight","SSC","HSC","Others"};
    String[] preference={"Select here","Uber","Personal","Personal & Uber","Company","Rent a Car","Contact a Car","Any job"};
    String[] experience={"Select here","1 Year","2 Years","3 Years","4 Years","5 Years","6 Years","7 Years","More than 10 Years"};
    String[] profession={"Select here","Doctor","Engineer"," Businessman","Politician","Teacher","Gov Officer"};
    String[] status={"Select here","Registred","Ready to Join","Working"};
    String[] accomadation={"Select here","Yes","No"};
    String[] lunch1={"Select here","Food","Money","Na"};

    Button birth_day,joindate,register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        register=findViewById(R.id.sign_up);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //registerProcess();
                Toast.makeText(Main2Activity.this,"Button Pressed",Toast.LENGTH_LONG);
            }
        });
        Spinner spinner_profession=findViewById(R.id.spinner_Profession);
        Spinner jobpreference=findViewById(R.id.spinner_jobpreference);
        Spinner education=findViewById(R.id.spinner_education);
        Spinner acomodation=findViewById(R.id.spinner_acomodation);
        Spinner lunch=findViewById(R.id.spinner_lunch);

        Spinner spinner_status=findViewById(R.id.spinner_status);
        Spinner spinner_religion=findViewById(R.id.spinner_religion);
        Spinner spinner_experience=findViewById(R.id.spinner_experience);


        birth_day=findViewById(R.id.button_date);
        initializeButton();


        spinner_profession.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa1 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,profession);
        aa1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        spinner_profession.setAdapter(aa1);

        jobpreference.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa2 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, preference);
        aa2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        jobpreference.setAdapter(aa2);

        education.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa3 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, education1);
        aa3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        education.setAdapter(aa3);

        acomodation.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa4 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, accomadation);
        aa4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        acomodation.setAdapter(aa4);

        lunch.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa5 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, lunch1);
        aa5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        lunch.setAdapter(aa5);

        spinner_status.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa6 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, status);
        aa6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        spinner_status.setAdapter(aa6);

        spinner_religion.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa7 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, religion);
        aa7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        spinner_religion.setAdapter(aa7);

        spinner_experience.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa8 = new ArrayAdapter(Main2Activity.this,android.R.layout.simple_spinner_item, experience);
        aa8.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        spinner_experience.setAdapter(aa8);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //registerProcess();
                Toast.makeText(Main2Activity.this,"Button Pressed",Toast.LENGTH_LONG);
            }
        });







    }

    private void registerProcess() {


        Response.Listener<String> responslistener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


                JSONObject jsonObject= null;
                try {
                    jsonObject = new JSONObject(response);
                    String result=jsonObject.getString("result");
                    if(result=="Success"){

                      Toast.makeText(Main2Activity.this,"you registered",Toast.LENGTH_LONG);
                    }
                    else{
                        Toast.makeText(Main2Activity.this,"not success",Toast.LENGTH_LONG);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Main2Activity.this,"network error",Toast.LENGTH_LONG);
                }




            }
        };
        RegisterRequest registerRequest=new RegisterRequest("alamin","khulna",122333 ,"alamingazi68","islam","engineer","software","khulna","uber","dhaka","bmw","2/3/2019",17000,"bsc","4year","nothing",10,"money","register","very good","passqww","alamingazi",responslistener);
    }

    private void initializeButton() {

        birth_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dialogFragment=new DatePickerFragment();
                dialogFragment.show(getSupportFragmentManager(),"date picker");

            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @SuppressLint("WrongConstant")
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

        java.util.Calendar calendar= java.util.Calendar.getInstance();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        String date = df.format(calendar.getTime());
    }
}
