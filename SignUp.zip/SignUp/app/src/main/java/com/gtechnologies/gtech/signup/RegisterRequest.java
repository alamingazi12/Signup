package com.gtechnologies.gtech.signup;

import android.support.annotation.StringRes;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;

public class RegisterRequest extends StringRequest {
    String ownername;
  private   Map<String,String> params;
    private static final String registerrequesturl="http://sd.smrobi.com/api/OwnerRegApi.php";
    public RegisterRequest(String ownerName,String presentAddress,int ownerMobile ,String ownerEmail,String religion,String professsion,String professsionDetails,String professsionAddress,String jobPreference,String jobLocation,String carName,String startDate,int offerSalary,String education,String expYear,String accomodation,int workingHours,String lunch,String status,String remarks,String pass,String userName, Response.Listener<String> listener ) {
        super(Method.POST,registerrequesturl,listener,null);
        params=new HashMap<String, String>();
        params.put("ownerName",ownerName);
        params.put("presentAddress",presentAddress);
        params.put("ownerMobile",ownerMobile+"");
        params.put("ownerEmail",ownerEmail);
        params.put("religion",religion);
        params.put("professsion",professsion);
        params.put("professsionDetails",professsionDetails);
        params.put("professsionAddress",professsionAddress);
        params.put("jobPreference",jobPreference);
        params.put("jobLocation",jobLocation);
        params.put("carName",carName);
        params.put("startDate",startDate);
        params.put("offerSalary",offerSalary+" ");
        params.put("education",education);
        params.put("expYear",expYear);
        params.put("accomodation",accomodation);
        params.put("workingHours",workingHours+" ");
        params.put("lunch",lunch);
        params.put("status",status);
        params.put("remarks",remarks);
        params.put("pass",pass);
        params.put("userName",userName);
        ownername=ownerName;


    }

    @Override
    public Map<String, String> getParams() {

        return params;
    }
}
